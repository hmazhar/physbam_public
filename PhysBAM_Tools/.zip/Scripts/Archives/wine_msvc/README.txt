Before operating you will need to run the setup.sh script as:

cd $PHYSBAM/Scripts/wine_msvc
sh ./setup
