#!/bin/bash

scp -P 1361 -l 35000 rfedkiw@bioxcluster:/home/rfedkiw/$1/* ./
